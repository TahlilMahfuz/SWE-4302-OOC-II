public enum StudentProgram {
    SWE, CSE, IT;
}

