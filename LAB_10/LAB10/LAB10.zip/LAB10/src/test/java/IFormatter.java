import java.io.File;
import java.util.List;

public interface IFormatter {
    public File format(List<Student> list);
}
