public class InvalidStudentIDException extends Exception{
    public InvalidStudentIDException(String str){
        super(str);
    }
}
