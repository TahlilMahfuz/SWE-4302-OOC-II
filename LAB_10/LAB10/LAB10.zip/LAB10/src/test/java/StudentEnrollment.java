import java.util.ArrayList;
import java.util.List;

public class StudentEnrollment {
    List<Student> students= new ArrayList<>();
    public void add(Student student){
        students.add(student);
    }
}
